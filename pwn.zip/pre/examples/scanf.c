#include <stdio.h>

int main(){
	char buf[32];
	scanf("%s",buf);
	return 0;
}



