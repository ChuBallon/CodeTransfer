#include <stddef.h>
#include <stdio.h>

void my_gets(char* s, size_t len){
	size_t i;
	for(i=0;i<len-1;i++){
		s[i]=getchar();
		if(s[i]=='\n')
			break;
	}
	s[i]='\0';
}

int main(){
	int len;
	char buf[32];
	scanf("%d\n",&len);
	if(len>32)
		return -1;
	my_gets(buf, len);
	return 0;
}


