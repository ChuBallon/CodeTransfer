//gcc ret2backdoor.c -fno-stack-protector -no-pie
#include<stdio.h>
#include<unistd.h>
void shell(){
	execve("/bin/sh",NULL,NULL);
}

int main(){
	char buf[16];
	scanf("%s",buf);
	return 0;
}


