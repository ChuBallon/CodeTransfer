#include<stdlib.h>
int main(){
	char* buf = (char*)malloc(114514);
	free(buf);
	*buf='a';
}


