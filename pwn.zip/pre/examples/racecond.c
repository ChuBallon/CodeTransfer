#include <stdio.h>
#include <pthread.h>

int total=1000000;

void* getgem(void* arg){
	int num=0;
	while(1){
		if(total>0){
			total--;
		} else {
			break;
		}
		num++;
	}
	printf("got %d gems\n", num);
	return NULL;
}

int main(){
	pthread_t t1,t2;
	pthread_create(&t1, NULL, getgem, NULL);
	pthread_create(&t2, NULL, getgem, NULL);
	pthread_join(t1, NULL);
	pthread_join(t2, NULL);
	return 0;
}

