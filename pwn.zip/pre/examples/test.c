#include<stdio.h>
#include<stdlib.h>
int foo(){
	int i = 114;
}


int main(){
	void* p = malloc(100);
	free(p);
	free(p);
}
