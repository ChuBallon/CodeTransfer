#include<stdio.h>

int main(){
	printf("Enter your lucky number\n");
	unsigned long long i=114514, num;
	scanf("%llu",&num);
	printf("Seems you like %llx\n",num);
}



