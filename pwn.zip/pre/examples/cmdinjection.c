#include<stdlib.h>
#include<stdio.h>
#include<string.h>

int main(){
	char buf[32];
	scanf("%31s", buf);
	char* cmd;
	if(asprintf(&cmd, "ping -c 4 %s", buf)!=-1)
		system(cmd);
}
