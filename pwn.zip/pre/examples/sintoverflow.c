#include <stdint.h>
#include <stdio.h>
int main(){
	int64_t a = INT64_MAX;
	printf("%d\n",a+1>a);
}


