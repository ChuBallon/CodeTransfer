#include <stdio.h>

int main(){
	unsigned money_total=500;
	unsigned money_used=0;
	unsigned primogem_price=1;
	while(1){
		unsigned amount=0;
		scanf("%u",&amount);
		unsigned total_price = primogem_price * amount;
		if(money_used + total_price > money_total){
			puts("Insufficient money");
		} else {
			money_used += total_price;
			printf("Got %u primogem\n", amount);
		}
		if(money_used==money_total)
			break;
	}
}

