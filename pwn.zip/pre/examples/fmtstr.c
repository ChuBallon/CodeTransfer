#include<stdio.h>
#include<string.h>
int main(){
	char name[32];
	scanf("%31s",name);
	char buf[64]="Hello, ";
	strcat(buf,name);
	printf(buf);
}


