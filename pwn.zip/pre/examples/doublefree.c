#include<stdlib.h>
int main(){
	void* p1 = malloc(114514);
	free(p1);
	free(p1);
}


