#include<stdio.h>
#include<assert.h>
int main(){
	int a=0;
	int b[3];
	int idx;
	scanf("%d",&idx);
	b[idx]=114514;
	printf("%d\n",a);
}


